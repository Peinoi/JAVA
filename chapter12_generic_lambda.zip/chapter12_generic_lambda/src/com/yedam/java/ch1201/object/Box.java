package com.yedam.java.ch1201.object;

public class Box {

	private Object content;

	public void setContent(Object content) {
		this.content = content;
	}

	public Object getContent() {
		return this.content;
	}
}
