package com.yedam.java.ch1202.lambda;

@FunctionalInterface
public interface Computer {
	public int cal(int x, int y);
}
