package com.yedam.java.ch1202.lambda;

@FunctionalInterface
public interface Action {
	public void speak(String content);
}
