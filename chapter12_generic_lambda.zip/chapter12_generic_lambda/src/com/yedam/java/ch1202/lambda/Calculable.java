package com.yedam.java.ch1202.lambda;

public interface Calculable {
	// 추상메서드 하나
	public void calculate(int x, int y);
}
