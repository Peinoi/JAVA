package com.yedam.java.ch1202.anonymous;

public interface RemoteControl {
	public void turnOff();
	public void turnOn();

}
